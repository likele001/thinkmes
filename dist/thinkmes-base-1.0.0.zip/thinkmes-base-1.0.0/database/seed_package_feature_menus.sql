-- 套餐功能对应的侧栏菜单（报表统计、数据导出、API接口访问、自定义字段、工作流、消息通知、数据备份）
-- 执行后超管与开通了对应功能的租户可见这些菜单；name 需与 tenant_package_feature.feature_code 一致
-- 表前缀与 .env DB_PREFIX 一致，默认 fa_

INSERT INTO `fa_auth_rule` (`name`, `title`, `type`, `ismenu`, `status`, `pid`, `icon`, `sort`, `create_time`, `update_time`) VALUES
('report', '报表统计', 1, 1, 1, 0, 'fas fa-chart-pie', 60, UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),
('export', '数据导出', 1, 1, 1, 0, 'fas fa-file-export', 61, UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),
('api', 'API接口访问', 1, 1, 1, 0, 'fas fa-plug', 62, UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),
('custom_field', '自定义字段', 1, 1, 1, 0, 'fas fa-list-alt', 63, UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),
('workflow', '工作流', 1, 1, 1, 0, 'fas fa-project-diagram', 64, UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),
('notification', '消息通知', 1, 1, 1, 0, 'fas fa-bell', 65, UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),
('backup', '数据备份', 1, 1, 1, 0, 'fas fa-database', 66, UNIX_TIMESTAMP(), UNIX_TIMESTAMP())
ON DUPLICATE KEY UPDATE `title` = VALUES(`title`), `icon` = VALUES(`icon`), `sort` = VALUES(`sort`), `ismenu` = VALUES(`ismenu`);
