/**
 * 系统配置：分组 tabs、按 group 拉取配置、表单保存
 */
(function () {
    var base = (typeof Config !== 'undefined' && Config.moduleurl) ? Config.moduleurl : '';
    var groupNames = { base: '基本', upload: '上传', safe: '安全', lang: '多语言', cache: '缓存' };

    var Controller = {
        index: function () {
            var $tabs = $('#config-tabs');
            var $form = $('#config-form');
            var $btnSave = $('#config-save');

            function loadGroups() {
                $.get(base + '/config/group', function (res) {
                    if (res.code !== 1 || !res.data || !res.data.length) return;
                    $tabs.empty();
                    res.data.forEach(function (g, i) {
                        var title = groupNames[g] || g;
                        var active = i === 0 ? ' active' : '';
                        $tabs.append('<li class="nav-item"><a class="nav-link' + active + '" href="javascript:;" data-group="' + g + '">' + title + '</a></li>');
                    });
                    var first = res.data[0];
                    if (first) loadGroup(first);
                }, 'json');
            }

            function loadGroup(group) {
                $form.empty().append('<p class="text-muted">加载中...</p>');
                $.get(base + '/config/index', { group: group }, function (res) {
                    $form.empty();
                    var rows = (res.code === 1 && res.data && res.data.length) ? res.data : [];
                    if (group === 'safe') {
                        var hasFrontCaptcha = rows.some(function (r) { return r.name === 'front_captcha_mode'; });
                        if (!hasFrontCaptcha) {
                            rows.push({
                                name: 'front_captcha_mode',
                                title: '前端验证码方式 (Captcha Mode)',
                                value: 'image',
                                group: 'safe'
                            });
                        }
                    }
                    if (group === 'upload') {
                        var hasUploadMax = rows.some(function (r) { return r.name === 'upload_max_size'; });
                        if (!hasUploadMax) {
                            rows.push({
                                name: 'upload_max_size',
                                title: '上传文件大小限制（字节）',
                                value: '52428800',
                                group: 'upload'
                            });
                        }
                        var hasChunkSize = rows.some(function (r) { return r.name === 'upload_chunk_size'; });
                        if (!hasChunkSize) {
                            rows.push({
                                name: 'upload_chunk_size',
                                title: '分片大小（字节）',
                                value: '2097152',
                                group: 'upload'
                            });
                        }
                    }
                    if (!rows.length) {
                        $form.append('<p class="text-muted">暂无配置项，可执行 database/seed_config.sql 初始化。</p>');
                        return;
                    }
                    rows.forEach(function (row) {
                        var name = row.name || '';
                        var title = row.title || name;
                        var value = (row.value != null && row.value !== undefined) ? String(row.value) : '';
                        var id = 'config_' + name.replace(/[^a-zA-Z0-9_]/g, '_');
                        if (name === 'front_captcha_mode') {
                            var options = [
                                { value: 'image', text: '数字图形验证码 / Image digits' },
                                { value: 'slider', text: '滑动解锁验证码 / Slider' },
                                { value: 'off', text: '关闭验证码 / Off' }
                            ];
                            var optsHtml = options.map(function (opt) {
                                var selected = (value === opt.value) ? ' selected' : '';
                                return '<option value="' + opt.value + '"' + selected + '>' + opt.text + '</option>';
                            }).join('');
                            $form.append(
                                '<div class="form-group row mb-2">' +
                                '<label class="col-sm-2 col-form-label" for="' + id + '">' + title + '</label>' +
                                '<div class="col-sm-6"><select class="form-control" id="' + id + '" name="' + name + '" data-group="' + (row.group || group) + '">' +
                                optsHtml +
                                '</select></div>' +
                                '</div>'
                            );
                        } else if (name === 'login_captcha') {
                            var onOffOptions = [
                                { value: '0', text: '关闭' },
                                { value: '1', text: '开启' }
                            ];
                            var onOffHtml = onOffOptions.map(function (opt) {
                                var selected2 = (value === opt.value) ? ' selected' : '';
                                return '<option value="' + opt.value + '"' + selected2 + '>' + opt.text + '</option>';
                            }).join('');
                            $form.append(
                                '<div class="form-group row mb-2">' +
                                '<label class="col-sm-2 col-form-label" for="' + id + '">' + title + '</label>' +
                                '<div class="col-sm-6"><select class="form-control" id="' + id + '" name="' + name + '" data-group="' + (row.group || group) + '">' +
                                onOffHtml +
                                '</select></div>' +
                                '</div>'
                            );
                        } else {
                            $form.append(
                                '<div class="form-group row mb-2">' +
                                '<label class="col-sm-2 col-form-label" for="' + id + '">' + title + '</label>' +
                                '<div class="col-sm-6"><input type="text" class="form-control" id="' + id + '" name="' + name + '" value="' + value.replace(/"/g, '&quot;') + '" data-group="' + (row.group || group) + '"></div>' +
                                '</div>'
                            );
                        }
                    });
                    $form.append('<input type="hidden" name="group" value="' + group + '">');
                }, 'json');
            }

            $(document).off('click', '#config-tabs .nav-link').on('click', '#config-tabs .nav-link', function () {
                var g = $(this).data('group');
                if (!g) return;
                $('#config-tabs .nav-link').removeClass('active');
                $(this).addClass('active');
                loadGroup(g);
            });

            $btnSave.on('click', function () {
                var group = $form.find('input[name="group"]').val() || 'base';
                var list = [];
                $form.find('input.form-control,select.form-control').each(function () {
                    var $el = $(this);
                    if ($el.attr('name') && $el.attr('name') !== 'group') {
                        list.push({ name: $el.attr('name'), value: $el.val(), group: $el.data('group') || group });
                    }
                });
                if (!list.length) {
                    if (typeof layer !== 'undefined') layer.msg('无配置项'); else alert('无配置项');
                    return;
                }
                $.post(base + '/config/save', { list: list }, function (res) {
                    if (res.code === 1) {
                        if (typeof layer !== 'undefined') layer.msg('保存成功'); else alert('保存成功');
                    } else {
                        if (typeof layer !== 'undefined') layer.msg(res.msg || '保存失败'); else alert(res.msg || '保存失败');
                    }
                }, 'json');
            });

            loadGroups();
        }
    };
    window.__backendController = Controller;
})();
