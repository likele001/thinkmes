<?php
use think\facade\Route;

Route::group('payment', function () {
    Route::get('config/index', 'payment.Config/index');
    Route::get('config/add', 'payment.Config/add');
    Route::get('config/edit', 'payment.Config/edit');
    Route::post('config/add', 'payment.Config/addPost');
    Route::post('config/edit', 'payment.Config/editPost');
    Route::post('config/del', 'payment.Config/del');
    Route::get('config/configFields', 'payment.Config/configFields');

    Route::get('order/index', 'payment.Order/index');
});
