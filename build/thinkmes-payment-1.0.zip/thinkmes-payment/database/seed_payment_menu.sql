-- 支付应用菜单
INSERT INTO `fa_auth_rule` (`name`, `title`, `type`, `ismenu`, `status`, `pid`, `icon`, `sort`, `create_time`, `update_time`)
VALUES ('payment', '支付管理', 1, 1, 1, 0, 'fa fa-credit-card', 90, UNIX_TIMESTAMP(), UNIX_TIMESTAMP())
ON DUPLICATE KEY UPDATE `title` = VALUES(`title`), `icon` = VALUES(`icon`), `sort` = VALUES(`sort`), `status` = VALUES(`status`);

SET @pay_pid = COALESCE((SELECT id FROM fa_auth_rule WHERE name = 'payment' LIMIT 1), 0);

INSERT INTO `fa_auth_rule` (`name`, `title`, `type`, `ismenu`, `status`, `pid`, `icon`, `sort`, `create_time`, `update_time`)
VALUES ('payment/config', '支付网关', 1, 1, 1, @pay_pid, 'fa fa-cog', 1, UNIX_TIMESTAMP(), UNIX_TIMESTAMP())
ON DUPLICATE KEY UPDATE `title` = VALUES(`title`), `pid` = @pay_pid;

SET @cfg_pid = COALESCE((SELECT id FROM fa_auth_rule WHERE name = 'payment/config' LIMIT 1), 0);
INSERT INTO `fa_auth_rule` (`name`, `title`, `type`, `ismenu`, `status`, `pid`, `icon`, `sort`, `create_time`, `update_time`) VALUES
('payment/config/index', '网关列表', 2, 0, 1, @cfg_pid, '', 0, UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),
('payment/config/add', '添加网关', 2, 0, 1, @cfg_pid, '', 0, UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),
('payment/config/edit', '编辑网关', 2, 0, 1, @cfg_pid, '', 0, UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),
('payment/config/del', '删除网关', 2, 0, 1, @cfg_pid, '', 0, UNIX_TIMESTAMP(), UNIX_TIMESTAMP())
ON DUPLICATE KEY UPDATE `pid` = @cfg_pid;

INSERT INTO `fa_auth_rule` (`name`, `title`, `type`, `ismenu`, `status`, `pid`, `icon`, `sort`, `create_time`, `update_time`)
VALUES ('payment/order', '支付订单', 1, 1, 1, @pay_pid, 'fa fa-list', 2, UNIX_TIMESTAMP(), UNIX_TIMESTAMP())
ON DUPLICATE KEY UPDATE `title` = VALUES(`title`), `pid` = @pay_pid;

SET @ord_pid = COALESCE((SELECT id FROM fa_auth_rule WHERE name = 'payment/order' LIMIT 1), 0);
INSERT INTO `fa_auth_rule` (`name`, `title`, `type`, `ismenu`, `status`, `pid`, `icon`, `sort`, `create_time`, `update_time`) VALUES
('payment/order/index', '订单列表', 2, 0, 1, @ord_pid, '', 0, UNIX_TIMESTAMP(), UNIX_TIMESTAMP())
ON DUPLICATE KEY UPDATE `pid` = @ord_pid;
